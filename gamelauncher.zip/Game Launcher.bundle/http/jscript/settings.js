var Secret = "17efae39eac45d35b8a656af17835317";
var PMSUrl = "192.168.1.10";
var baseurl = "http://"+PMSUrl+":32400";
var utility = "/video/gamelauncher";
var PathToPlexMediaFolder = "/Users/aequitas/Library/Application Support/Plex Media Server";
var Version = "0.0.0.2";

var options_hide_integrated = "true";
var options_hide_local = "true";
var options_hide_empty_subtitles = "true";
var options_only_multiple = "true";
var options_auto_select_duplicate = "false";
var items_per_page = "15";

var fatal_error = false;
